import matplotlib.pyplot as plt
import time as time
import math as math
import numpy as np
from numpy import cos, sin, exp, log
from math import pi
import dynamics.dyn as dyn

Linf = lambda x : abs(x).max()

def run_with_scalars(model,dyn_scheme,transport,replace, plotter, 
                     courant,flow0,scalars, T1, N1, N2):
    metric, BC = model.metric, model.BC
    mik, gas0, ujk, Phi_il, Wil = model.diagnose(*flow0)
    ztop = Phi_il.max()/metric.g0
    Phi_ik = metric.mk_int(Phi_il)
    vol, jac = metric.volume(Phi_il[:,-1])
    internal0 = (mik*(gas0.e+Phi_ik)).sum() + BC.ptop*vol.sum()

    dtmax, dt_hydro = model.max_time_step(gas0,mik)
    dt=courant*dtmax # RK4 stability limit is courant=2.sqrt(2)
    
    N0 = int(math.ceil(float(T1)/dt))
    dt=T1/N0 # adjust time step to fraction of T1
    step = dyn_scheme(dt)
    print ('dt (s)', step.dt, 'Horizontal acoustic Courant number', dt/dt_hydro)
    
    Sik = mik*gas0.s
    flow0 = mik, Sik, ujk, Phi_il, Wil, 0.,0.
    elapsed=time.time()
    flow=step.advance(flow0,10)
    elapsed = (time.time()-elapsed)/10
    print ("Elapsed time per time step (ms)", elapsed*1e3)
    print ("Simulated time / elapsed time  (s/s)", step.dt/elapsed)
        
    out=[flow0]
    kinetic=[]
    internal=[]
    for i in range(N2):
        for j in range(N1):
            for k in range(int(N0/2)):
                mik_old = mik
                mik, Sik, ujk, Phi_il, Wil, Fjk, Fil = step.next((mik, Sik, ujk, Phi_il, Wil, 0.,0.))
                mik, Sik, ujk, Phi_il, Wil, Fjk, Fil = step.next((mik, Sik, ujk, Phi_il, Wil, Fjk, Fil))
                # transport scalars using time-integrated mass fluxes Fjk, Fil
                mik_new, scalars = transport.next(Fjk,Fil,mik_old,scalars)
                Sik = replace(Sik,scalars[0]) # replace (or not) entropy by FV-transported scalar
                # print Linf(mik-mik_new)/Linf(mik)
            mik, gas_ik, ujk, Phi_il, Wil = model.diagnose(mik, Sik, ujk, Phi_il, Wil)
            Phi_ik = metric.mk_int(Phi_il)
            vol, jac = metric.volume(Phi_il[:,-1])
            kinetic.append(model.kinetic(mik, ujk, Wil, Phi_il))
            internal.append((mik*(gas_ik.e+Phi_ik)).sum() + BC.ptop*vol.sum())
            print ('\r', i*N1+j+1, '/', N1*N2,
        plotter(metric, (mik, Sik, ujk, Phi_il, Wil), scalars, (i+1)*T1*N1) )
        
    kinetic=np.array(kinetic)
    internal=np.array(internal)
    dE=kinetic+internal-internal0
    plt.figure(figsize=(12,3))
    plt.plot(dE/kinetic.max())
    plt.figure(figsize=(12,3))
    plt.plot(kinetic/kinetic.max())
    plt.show()

    return mik,scalars

def run(model,scheme,plotter, courant,flow0, T1, N1, N2):
    metric, BC = model.metric, model.BC
    mik, gas0, ujk, Phi_il, Wil = model.diagnose(*flow0)
    ztop = Phi_il.max()/metric.g0
    Phi_ik = metric.mk_int(Phi_il)
    vol, jac = metric.volume(Phi_il[:,-1])
    internal0 = (mik*(gas0.e+Phi_ik)).sum() + BC.ptop*vol.sum()

    dtmax, dt_hydro = model.max_time_step(gas0,mik)
    dt=courant*dtmax # RK4 stability limit is courant=2.sqrt(2)
    
    N0 = int(math.ceil(float(T1)/dt))
    dt=T1/N0 # adjust time step to fraction of T1
    step = scheme(dt)
    print ('dt (s)', step.dt, 'Horizontal acoustic Courant number', dt/dt_hydro)
    
    elapsed=time.time()
    flow=step.advance(flow0,10)
    elapsed = (time.time()-elapsed)/10
    print ("Elapsed time per time step (ms)", elapsed*1e3)
    print ("Simulated time / elapsed time  (s/s)", step.dt/elapsed)
        
    out=[flow0]
    flow=flow0
    kinetic=[]
    internal=[]
    for i in range(N2):
        step.sanity_checks(flow)
        for j in range(N1):
            mik, gas_ik, ujk, Phi_il, Wil = model.diagnose(*flow)
            Phi_ik = metric.mk_int(Phi_il)
            vol, jac = metric.volume(Phi_il[:,-1])
            kinetic.append(model.kinetic(mik, ujk, Wil, Phi_il))
            internal.append((mik*(gas_ik.e+Phi_ik)).sum() + BC.ptop*vol.sum())
            print ('\r', i*N1+j+1, '/', N1*N2)
            flow = step.advance(flow,N0)
        plotter(metric, flow, (i+1)*T1*N1)
        
    kinetic=np.array(kinetic)
    internal=np.array(internal)
    dE=kinetic+internal-internal0
    plt.figure(figsize=(12,3))
    plt.plot(dE/kinetic.max())
    plt.figure(figsize=(12,3))
    plt.plot(kinetic/kinetic.max())
    plt.show()

def DCMIP21(Lx,Nx,llm, ztop=3e4, h0=250., 
            dd=5000., xi=4000., Ueq=20.) :
    """ DCMIP2.1 experiment at equator (phi=0)"""
    Cpd, Rd, pref, Tref, = 1004.5, 287., 1e5, 273.15
    g, p0, peq, Teq = 9.81, 1e5, 1e5, 300.

    p=lambda x,Phi : peq*np.exp(-Phi/(Rd*Teq))
    ptop = p(0,g*ztop)
    print ('ptop (Pa) =', ptop)

    xmesh  = dyn.Periodic_FD(Nx)
    zmesh  = dyn.Lorenz(llm)
    mesh   = dyn.Slice(xmesh,zmesh)
    metric = dyn.Shallow(mesh, Lx/Nx,g)
    thermo = dyn.Ideal_perfect(Cpd, Rd, pref, Tref)

    T=lambda x,Phi : Teq
    gauss=lambda x: np.exp(-x*x)
    cos2=lambda x: cos(pi*x)**2
    Phis = lambda x:g*h0*gauss(x/dd)*cos2(x/xi)
    Phi = lambda x,eta : g*ztop*eta + (1.-eta)*Phis(x)
    mik, gas, Phi_il = metric.inicond_NH(thermo, Phi,p,T)
    ujk = 0*mik + Ueq*(Lx/Nx)
    
    print ('ztop (m) = ', Phi_il[0,-1]/g, ztop)
    print ('ptop (Pa) = ', gas.p[0,-1], ptop)
    Phi_bot = Phi_il[:,0:1]
    gas_bot=thermo.set_pT(p(metric.xil[:,0:1], Phi_bot), Teq)
    BC = dyn.BoundCond(ptop, Phi_bot, gas_bot.p, 1./gas_bot.v)
    return metric, thermo, BC, mik, gas, Phi_il, ujk

def DCMIP31(Lx,Nx,llm,deform=lambda x,eta:0, dTheta=1., d2=25e6) :
    """ DCMIP3.1 initial condition with Phi(x,eta)=g.ztop*(eta + deform(eta,x/L)) """
    # DCMIP 3.1 at equator (phi=0)
    Cpd, Rd, pref, Tref, = 1004.5, 287., 1e5, 273.15
    g, p0, ptop = 9.81, 1e5, 27391.9
    peq, N2, Teq, ztop = 1e5, 1e-4, 300., 1e4

    G=g**2/(Cpd*N2)
    inv_G=1./G
    inv_Teq=1./Teq
    G_Teq = G/Teq

    p=lambda x,Phi : peq*((1-G_Teq*(1-np.exp(-N2*Phi/g**2)))**(Cpd/Rd))
    ptop = p(0,g*ztop)
    print( ptop)

    xmesh  = dyn.Periodic_FD(Nx)
    zmesh  = dyn.Lorenz(llm)
    mesh   = dyn.Slice(xmesh,zmesh)
    metric = dyn.Shallow(mesh, Lx/Nx,g)
    thermo = dyn.Ideal_perfect(Cpd, Rd, pref, Tref)

    ps = lambda xi: peq+0*xi
    fac = lambda p : (p/peq)**(Rd/Cpd)
    T = lambda x,p : fac(p)/(inv_G*(fac(p)-1)+inv_Teq)
    u = lambda xjk,pjk : 0*xjk

    Phi = lambda x,eta : g*ztop*(eta+deform(x/Lx,eta))
    m0ik, gas, Phi0_il = metric.inicond_NH(thermo, Phi,p,T)
    u0_jk = 0*m0ik
    
    Tb  = gas.T # unperturbed temperature

    print ('ztop (m) = ', Phi0_il[0,-1]/g, ztop)
    print ('ptop (Pa) = ', gas.p[0,-1], ptop)
    Phi_bot = Phi0_il[:,0:1]
    pbot = p(metric.xil[:,0:1], Phi_bot)
    gas_bot=thermo.set_pT(pbot, T(metric.xil[:,0:1],pbot))
    BC = dyn.BoundCond(ptop, Phi_bot, gas_bot.p, 1./gas_bot.v)
    print( BC.rho_bot.shape)
    
    # now add localized temperature perturbation
    xik = metric.xik
    pik = gas.p
    zik = zmesh.mk_int(Phi0_il)/g
    shape = d2/(d2+xik*xik)
    shape = shape*np.sin(math.pi*zik/ztop)
    shape = shape*((pik/p0)**(Rd/Cpd))
    gas0 = thermo.set_pT(pik, Tb + dTheta*shape)

    return metric, thermo, BC, m0ik, gas0, Phi0_il, u0_jk

def thermal_bubble(Lx,Nx,llm, ztop=1000., zc=200., rc=250, thetac=0.5, x0=0.0):
    """Hi"""
    Cpd, Rd, g, p0,theta0, T0 = 1004.5, 287.,9.81, 1e5, 300., 300.

    Phis = lambda x: 0.0
    Phi = lambda x,eta : g*ztop*eta + (1.-eta)*Phis(x)
    p=lambda x, Phi : p0*np.exp(-Phi/(Rd*T0))
    ptop = p(0,g*ztop)
    print ('ptop (Pa) =', ptop)
    xmesh  = dyn.Periodic_FD(Nx)
    zmesh  = dyn.Lorenz(llm)
    mesh   = dyn.Slice(xmesh,zmesh)
    metric = dyn.Shallow(mesh, Lx/Nx,g)
    thermo = dyn.Ideal_perfect(Cpd, Rd, p0, T0)
    
    zz = lambda p: -(Rd*T0*np.log(p/p0))/g
    rr =   lambda x, p: np.sqrt((x-x0)**2 + (zz(p)-zc)**2)
    sa = lambda x,p: rr(x,p) < rc
    deform = lambda x,p: (0.5*thetac*(1+cos(pi*rr(x,p)/rc)))*sa(x,p)
    temp =  lambda x, p: theta0*(p/p0)**(Rd/Cpd)
    T = lambda x,p: deform(x,p) + temp(x,p)
       
    #T = lambda x, Phi: T0
    mik, gas, Phi_il = metric.inicond_NH(thermo, Phi,p,T)
    ujk = 0*mik
        
    print ('ztop (m) = ', Phi_il[0,-1]/g, ztop)
    print ('ptop (Pa) = ', gas.p[0,-1], ptop)
    Phi_bot = Phi_il[:,0:1]
    gas_bot=thermo.set_pT(p(metric.xil[:,0:1], Phi_bot), T0) #### T ot T0 
    BC = dyn.BoundCond(ptop, Phi_bot, gas_bot.p, 1./gas_bot.v)
    return metric, thermo, BC, mik, gas, Phi_il, ujk


def density_current(Lx,Nx,llm,ztop=6500., zc=3000.):
    """  Straka et al, 1993: 
    Numerical Solutions of a Nonlinear Density-Current - A Benchmark Solution and Comparisons.
         International Journal for Numerical Methods in Fluids, 1-22. """
    Cpd, Rd, g, p0,theta0, T0= 1004.5, 287.,9.81, 1e5, 300., 300.
    zr, x0, xr=2000., 0.0, 4000.
    Phis = lambda x: 0.0 
    Phi = lambda x,eta : g*ztop*eta + (1.-eta)*Phis(x)
    Tbar = lambda x,Phi: T0 - Phi*(Cpd**-1.)
    p=lambda x, Phi : p0*(Tbar(x,Phi)/T0)**(Cpd/Rd)
    ptop = p(0,g*ztop)
    print ("ptop",ptop) 
    xmesh  = dyn.Periodic_FD(Nx)
    zmesh  = dyn.Lorenz(llm)
    mesh   = dyn.Slice(xmesh,zmesh)
    metric = dyn.Shallow(mesh, Lx/Nx,g)
    thermo = dyn.Ideal_perfect(Cpd, Rd, p0, T0) 
    
    zz = lambda p: Cpd*T0*(1.-(p/p0)**(Rd/Cpd))/g     
    LL = lambda x,p: np.sqrt(((x-x0)*(xr**-1.))**2. + ((zz(p)-zc)*(zr**-1.))**2.)
    sa = lambda x,p: LL(x,p) <= 1.
    sb = lambda x,p: LL(x,p) > 1.
    Thetaperturb = lambda x,p: (-7.5*(cos(pi*LL(x,p)) + 1.0 ))*sa(x,p) +sb(x,p)*0.0
    Tperturb = lambda x, p: Thetaperturb(x,p)*(p/p0)**(Rd/Cpd)
    Tb = lambda x,p: T0 - g*zz(p)*(Cpd**-1.) 
    T = lambda x,p:  Tb(x,p) + Tperturb(x,p)   ### IS Tfinal = Tbar + Tperturb ??
    
    mik, gas, Phi_il = metric.inicond_NH(thermo, Phi,p,T)
    Tb0 = Tb(metric.xik,gas.p)
    ujk = 0*mik
    print ('ztop (m) = ', Phi_il[0,-1]/g, ztop)
    print ('ptop (Pa) = ', gas.p[0,-1], ptop, gas.p[0,0])
    print ('T surface and top', gas.T[0,0],gas.T[0,-1])
    Phi_bot = Phi_il[:,0:1]
    gas_bot=thermo.set_pT(p(metric.xil[:,0:1], Phi_bot), T0) #### T ot T0 
    BC = dyn.BoundCond(ptop, Phi_bot, gas_bot.p, 1./gas_bot.v)
    return metric, thermo, BC, mik, gas, Phi_il, ujk, Tb0 
    
