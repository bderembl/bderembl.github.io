import numpy as np
from scipy import sparse as sparse
import math as math
import dynamics.time_step as time_step

class Struct: pass

def Linf(data):
    return abs(data).max()
def compare(msg, data1, data2):
    print (msg, Linf(data1-data2)/Linf(data1))    

def col_vec(data):
    vec=np.zeros((data.size,1))
    vec[:,0]=data
    return vec
def row_vec(data):
    vec=np.zeros((1,data.size))
    vec[0,:]=data
    return vec

zero=np.zeros((1))

####################### Horizontal mesh #########################

class Periodic_FD:
    # staggering
    # m0  m1  m2  m3
    #   u0  u1  u2  u3
    def __init__(self, N):
        self.N=N
        ones=np.ones(N);

        right = sparse.spdiags([ones],[0],N,N, format='csr')
        left = sparse.spdiags([ones],[-1],N,N, format='csr')
        left[0,-1]=1
        di = right-left
        mi = .5*(right+left)
        self.di=lambda f:di.dot(f)
        self.mi=lambda f:mi.dot(f)
        self.xi = col_vec(np.linspace(0,N-1,N))-N/2.
        self.onesi = np.ones((N,1))
        self.zeroi = np.zeros((N,1))
        
        right = sparse.spdiags([ones],[1],N,N, format='csr')
        right[-1,0]=1
        left = sparse.spdiags([ones],[0],N,N, format='csr')
        dj = right-left
        mj = .5*(right+left)
        self.dj=lambda f:dj.dot(f)
        self.mj=lambda f:mj.dot(f)
        self.xj = col_vec(np.linspace(0.5,N-.5,N))-N/2.
        self.onesj = np.ones((N,1))

############################## Vertical mesh ############################

class Lorenz:
    def __init__(self, llm):
        self.llm = llm
        self.onesk = np.ones((1,llm))
        self.onesl = np.ones((1,llm+1))
        self.etak = row_vec(np.linspace(.5/llm,1.-.5/llm,llm))
        self.etal = row_vec(np.linspace(0.,1.,llm+1))
    def fieldk(self,N):
        return np.zeros((N,self.llm))
    def fieldl(self,N):
        return np.zeros((N,self.llm+1))
    def dk(self, fl):
        return fl[:,1:]-fl[:,:-1]
    def dl(self, fbot, fk, ftop): 
    # vertical FD from k to l with extra info at top/bottom 
        llm=self.llm
        gbot = fk[:,0:1]-fbot 
        gl = fk[:,1:]-fk[:,:-1]
        gtop = ftop-fk[:,llm-1:llm]
        return np.array(np.hstack((gbot,gl,gtop)))
    # Vertical averaging, fac=1 or 1/2 is weight of boundary contributions
    # mk and ml with same fac are adjoint
    # ml_ext, mk_int use fac=1/2
    # mk_ext, ml_int use fac=1
    def ml(self, fk, fac): # fk has size llm, last index llm-1
        llm=self.llm
        fbot, ftop = fk[:,0:1], fk[:,llm-1:llm]
        fl = .5*(fk[:,1:]+fk[:,:-1]) # size llm-1
        return np.array(np.hstack((fac*fbot,fl,fac*ftop))) # size llm+1
    def mk(self, fl, fac): # fl has size llm+1, last index llm
        llm=self.llm
        fbot = fac*fl[:,0:1] + .5*fl[:,1:2]
        ftop = fac*fl[:,llm:llm+1] + .5*fl[:,llm-1:llm]
        fk = .5*(fl[:,2:-1]+fl[:,1:-2]) # size llm-2
        return np.array(np.hstack((fbot,fk,ftop)))  # size llm
    # Averaging of extensive fields
    def ml_ext(self, fk): return self.ml(fk,.5)
    def mk_ext(self, fl): return self.mk(fl,1.)
    # Averaging of intensive fields
    def ml_int(self, fk): return self.ml(fk,1.)
    def mk_int(self, fl): return self.mk(fl,.5)
    
############################## Slice #############################

class Slice:
    def __init__(self, xmesh, zmesh):
        self.xmesh, self.zmesh = xmesh, zmesh
        self.xik = xmesh.xi*zmesh.onesk
        self.xjk = xmesh.xj*zmesh.onesk
        self.xil = xmesh.xi*zmesh.onesl
        self.xjl = xmesh.xj*zmesh.onesl
        self.etaik = xmesh.onesi*zmesh.etak
        self.etail = xmesh.onesi*zmesh.etal
        self.etajk = xmesh.onesj*zmesh.etak
        self.etajl = xmesh.onesj*zmesh.etal
        self.ones_ik=xmesh.onesi*zmesh.onesk
    def field_ik(self):
        return self.zmesh.fieldk(self.xmesh.N)
    def field_il(self):
        return self.zmesh.fieldl(self.xmesh.N)
    def field_jk(self):
        return self.zmesh.fieldk(self.xmesh.N)
    def field_jl(self):
        return self.zmesh.fieldl(self.xmesh.N)
    def cumsum_il(self, f0, dkf):
        f_il = np.hstack((f0, dkf))
        return np.cumsum(f_il,axis=1)

########################## Thermodynamics #########################

class Gas:
    def dp(self, dvol_ik):
        """ Variations of p,T,g at constant s """
        dpik = -self.c2*dvol_ik/(self.v*self.v) # dp/dv = -(1/v2)dp/drho
        dTik = -self.dpds*dvol_ik # dp/ds = -d2e/dvds = -dT/dv
        dgik = self.v*dpik-self.s*dTik # dG = vdp - sdT
        return dpik, dTik, dgik
    
class Ideal_perfect:
    def __init__(self,Cpd,Rd,p0,T0):
        # make sure everything is floating-point
        self.Cpd = 1.*Cpd
        self.Cvd = 1.*Cpd-Rd
        self.Rd  = 1.*Rd
        self.T0  = 1.*T0
        self.p0  = 1.*p0
        self.v0  = Rd*T0/(1.*p0)
    def set_ps(self,p,s):
        Cpd = self.Cpd ; Rd = self.Rd
        T = self.T0*np.exp( (s + Rd*np.log(p/self.p0))/Cpd )
        return self.energies(p,Rd*T/p,T,s)
    def set_vs(self,v,s):
        Cvd = self.Cvd ; Rd = self.Rd
        T = self.T0*np.exp( (s - Rd*np.log(v/self.v0))/Cvd )
        return self.energies(Rd*T/v,v,T,s)
    def set_pT(self,p,T):
        Cpd = self.Cpd ; Rd = self.Rd
        s = Cpd*np.log(T/self.T0) - Rd*np.log(p/self.p0)
        return self.energies(p,Rd*T/p,T,s)
    def set_vT(self,v,T):
        Cvd = self.Cvd ; Rd = self.Rd
        s = Cvd*np.log(T/self.T0) + Rd*np.log(v/self.v0)
        return self.energies(Rd*T/v,v,T,s)
    def energies(self,p,v,T,s):
        gas = Gas();
        gas.p, gas.v, gas.T, gas.s = p, v, T, s
        gas.dpds = p/self.Cvd
        gas.c2=((self.Cpd/self.Cvd)*self.Rd)*T
        gas.e = self.Cvd*T
        gas.h = self.Cpd*T
        gas.g = gas.h-T*s
        return gas

################################# Dynamics ##############################

class BoundCond:
    def __init__(self, ptop, Phi_bot, pbot, rho_bot):
        self.ptop, self.Phi_bot = ptop, Phi_bot # standard BC
        self.pbot, self.rho_bot = pbot, rho_bot # soft ground
        self.rigid_bottom, self.rigid_top = True, True # by default
        self.sponge = lambda Phi,ujk,dujk,tau : (ujk+tau*dujk,dujk)
        
class Dynamics:
    def __init__(self, thermo, metric, BC, fac=(1,1,1)):
        self.thermo, self.metric = thermo, metric
        self.BC, self.fac = BC, fac
        self.di, self.dj = metric.di, metric.dj
        self.dk, self.dl = metric.dk, metric.dl
        self.mi, self.mj = metric.mi, metric.mj
        self.mk_ext, self.ml_ext = metric.mk_ext, metric.ml_ext
        self.mk_int, self.ml_int = metric.mk_int, metric.ml_int
    def kinetic(self,mik,ujk,Wil,Phi_il):
        djPhil = self.dj(Phi_il)
#        ujk, Wil, djPhil = self.mult_by_fac((ujk, Wil, djPhil))
        return self.metric.kinetic(mik, ujk, Wil, djPhil)
    def time_steps(self,gas,mik) :
        dx = self.metric.dx
        cmax, dz = np.sqrt(gas.c2.max()), gas.v*mik/dx
        print ('Min/max layer thickness (m)', dz.min(), dz.max())
        dz=dz.min()
        dt_hydro=.5*dx/cmax
        dt_NH=.5/cmax/math.sqrt(dx**-2+dz**-2)
        print ('Horizontal resolution (m)', dx)
        print ('Max temperature (K), sound speed (m/s)', gas.T.max(), cmax)
        print ('Courant number 1 times steps for HPE and NH (s) : ', dt_hydro, dt_NH)
        return dt_NH, dt_hydro

############################## Hydrostatic dynamics ###########################

class Shallow_hydro: # hydrostatic routines of the Shallow class defined at the end
    def hydrostatic_pressure(self, ptop, mik):
        M_il=np.cumsum(mik,1)
        Mtop_il=col_vec(M_il[:,-1])*self.zmesh.onesk
        M_ik = Mtop_il - M_il + .5*mik
        return ptop + M_ik*self.g0_dx
    def geopotential(self, Phi0_i, mik, gas):
        dkphi = mik*gas.v*self.g0_dx
        phi_il = self.mesh.cumsum_il(Phi0_i, dkphi)
        return phi_il
    def hydrostatic_adjustment(self, thermo, BC, mik, sik):
        pik=self.hydrostatic_pressure(BC.ptop, mik)
        gas=thermo.set_ps(pik, sik)
        Phi_il=self.geopotential(BC.Phi_bot, mik, gas)
        return Phi_il, gas
    def dK_hydro(self, mik, ujk):
        """Partial derivatives of HPE kinetic energy"""
        Ujk=self.mj(mik)*ujk/self.dx2
        Kik=(.5/self.dx2)*self.mi(ujk*ujk)
        return Kik, Ujk
    def inicond(self, hybrid, thermo, ps, T, u):
        """Hydrostatic initialization given
        surface pressure, temperature, horiz vel""" 
        Mi=(ps(self.xi)-self.ptop)*self.dx_g0
        mik=hybrid.mik(Mi)
        pik=self.hydrostatic_pressure(mik)
        Tik=T(self.xik, pik)
        gas=thermo.set_pT(pik, Tik)
        Phi_il=self.geopotential(mik, gas)
        pjk=self.mj(pik)
        ujk=self.dx*u(self.xjk,pjk)
        return Mi, mik, gas, Phi_il, ujk

class Hydrostatic(Dynamics):
    def __init__(self,  thermo, metric, BC):
        Dynamics.__init__(self, thermo, metric, BC, (1,0,0))
    def max_time_step(self,gas,mik):
         dt_NH, dt_hydro = self.time_steps(gas,mik)
         return dt_hydro, dt_hydro
    def diagnose(self,mik,Sik,ujk,Phi_il,Wil):
        Phi_il, gas_ik = self.metric.hydrostatic_adjustment(
                                    self.thermo, self.BC, mik, Sik/mik)
        return mik,gas_ik,ujk,Phi_il,0*Phi_il
    def dH(self, mik, sik, ujk):
        Phi_il, gas_ik = self.metric.hydrostatic_adjustment(
                                    self.thermo, self.BC, mik, sik)
        Kik, Ujk = self.metric.dK_hydro(mik, ujk)
        Bik = Kik + self.mk_int(Phi_il) + gas_ik.g
        return Bik, gas_ik, Ujk, Phi_il
    def bwd_fast_slow(self, mik, Sik, ujk, tau):
        sik = Sik/mik
        Phi_il, gas_ik = \
            self.metric.hydrostatic_adjustment(self.thermo, self.BC, mik, sik)
        sjk = self.mj(sik)
        Bik = self.mk_int(Phi_il) + gas_ik.g
        dujk_fast = -self.dj(Bik)-sjk*self.dj(gas_ik.T)
        ujk, dujk_fast = self.BC.sponge(Phi_il, ujk, dujk_fast, tau) # updates ujk, dujk_dt
        Kik, Fjk = self.metric.dK_hydro(mik, ujk)
        dSik = -self.di(sjk*Fjk)
        dujk = -self.dj(Kik)
        return ujk, dujk_fast, Fjk, dSik, dujk 

############################## NH dynamics ###########################

class Shallow_NH: # NH routines of the Shallow class defined at the end
    def wil(self, mik, Wil):
        mil=self.ml_ext(mik)
        return mil, Wil/mil
    def lambda_il(self,djPhil):
        return self.mi(djPhil*djPhil)/self.dx2
    def kinetic(self, mik, ujk, Wil, djPhil):
        """NH kinetic energy - coincides with HPE if Wil=0"""
        dx2,mi,mj,ml_int=self.dx2, self.mi, self.mj, self.ml_int
        mil,wil = self.wil(mik,Wil)
        lambda_il = (self.lambda_il(djPhil) + self.g2)*wil
        Kjk = (.5/dx2)*mj(mik)*ujk**2
        Kjl = (1./dx2)*djPhil*ml_int(ujk)*mj(Wil)
        Kil = .5*lambda_il*Wil
        return Kjk.sum()-Kjl.sum()+Kil.sum()
    def dK_NH_horiz(self, mik, ujk, Wil, djPhil):
        """Partial derivatives of horizontal kinetic energy"""
        dx2, mi, mj = self.dx2, self.mi, self.mj
        mk_ext, mk_int, ml_int = self.mk_int, self.mk_int, self.ml_int
        mil, wil = self.wil(mik,Wil)
        lambda_il = wil*self.lambda_il(djPhil)
        djPhi_W = mk_ext(djPhil*mj(Wil))
        dK_dujk = (mj(mik)*ujk-djPhi_W)/dx2
        dK_dmik = (.5/dx2)*mi(ujk*ujk) - .5*mk_int(lambda_il*wil)
        ujl = ml_int(ujk)
        dK_dWil = lambda_il - mi(djPhil*ujl)/dx2
        dK_djPhil = (djPhil*mj(Wil*wil)-mj(Wil)*ujl)/dx2
        return dK_dmik, dK_dujk, dK_dWil, dK_djPhil
    def dK_NH_vert(self, mik, Wil):
        """Partial derivatives of vertical kinetic energy,  
        also returns mil,wil to be used by HEVI solver"""
        mil, wil = self.wil(mik,Wil)
        dK_dWil = self.g2*wil
        dK_dmik = -.5*self.mk_int(dK_dWil*wil)
        return dK_dmik, dK_dWil, mil, wil
    def inicond_NH(self, thermo, Phi, p, T):
        """ Initialization given Phi(x,eta), p(x,Phi), T(x,p) """
        Phi_il = Phi(self.xil, self.mesh.etail)
        Phi_ik = Phi(self.xik, self.mesh.etaik)
        pik = p(self.xik, Phi_ik)
        gas = thermo.set_pT(pik, T(self.xik,pik))
        vol, Jac = self.volume(Phi_il)
        mik = self.dk(vol) / gas.v
        return mik, gas, Phi_il
    def solver_NH(self, BC, dt, mik,Jac_il,gas_ik,mil):
        dx_g0, g2 = self.dx_g0, self.g2
        Ak = (dt*dx_g0/gas_ik.v)**2
        Ak = gas_ik.c2/mik*Ak
        ml_g2 = mil/g2
        Bl = 2*self.ml_ext(Ak) + ml_g2
        Bl[:,0:1] = Bl[:,0:1] + (dx_g0*dt*dt)*BC.rho_bot
        return time_step.SymTriDiag(Bl,Ak), ml_g2

class Nonhydro(Dynamics):
    def max_time_step(self,gas,mik):
         dt_NH, dt_hydro = self.time_steps(gas,mik)
         return dt_hydro, dt_hydro
    def diagnose(self,mik,Sik,ujk,Phi_il,Wil):
        vol_il,dvol_il = self.metric.volume(Phi_il)
        gas_ik = self.thermo.set_vs(self.dk(vol_il)/mik, Sik/mik)
        return mik,gas_ik,ujk,Phi_il,Wil
    def pressure(self, mik,sik,Phi_il):
        BC, metric = self.BC, self.metric
        vol_il, Jac_il = metric.volume(Phi_il)
        gas_ik = self.thermo.set_vs(self.dk(vol_il)/mik, sik)
        pbot = BC.pbot + BC.rho_bot*(BC.Phi_bot-Phi_il[:,0:1])
        ptop = BC.ptop*metric.mesh.ones_ik[:,0:1]
        return gas_ik, Jac_il, self.dl(pbot, gas_ik.p, ptop)
    def bwd_fast_slow(self, mik,Sik,ujk,Phi_il,Wil, tau):
        di, dj, dk, dl = self.di, self.dj, self.dk, self.dl
        BC, metric = self.BC, self.metric
        sik = Sik/mik
        mil, wil = metric.wil(mik,Wil)
        # solve Phi_il - (tau**2)*X.dl(pk) = Phi_star_il
        if tau>0.:
            Phi_star_il = Phi_il + tau*metric.g2*(wil - tau)
            # Newton iteration : Phi_il contains current guess value
            for ii in range(2):
                gas_ik, Jac_il, dl_pi = self.pressure(mik,sik,Phi_il)
                tridiag, ml_g2 = metric.solver_NH(BC, tau, mik,Jac_il,gas_ik,mil)
                residual = (ml_g2*(Phi_il-Phi_star_il)
                            +tau*tau*Jac_il*dl_pi)
                dPhi_il = tridiag.solve(residual)
                Phi_il = Phi_il - dPhi_il
        # update Wil
        gas_ik, Jac_il, dl_pi = self.pressure(mik,sik,Phi_il)
        dH_Phiil = mil + Jac_il*dl_pi
        Wil = Wil - tau*dH_Phiil
        # update ujk
        dK_mik, dPhiil_fast, mil, wil = metric.dK_NH_vert(mik, Wil)
        dH_mik = dK_mik + self.mk_int(Phi_il) + gas_ik.g
        sjk = self.mj(sik)
        dujk_fast = -dj(dH_mik)-sjk*dj(gas_ik.T)
        ujk, dujk_fast = self.BC.sponge(Phi_il, ujk, dujk_fast, tau)
        # slow trends
        djPhil = dj(Phi_il)
        Bik, Fjk, dPhiil_slow, dK_djPhil = self.metric.dK_NH_horiz(mik, ujk, Wil, djPhil)
        dSik_slow = -di(sjk*Fjk)
        dujk_slow = -dj(Bik)
        dWil_slow = di(dK_djPhil)
        return  ( ujk,Phi_il,Wil,                               # updated flow state
                dujk_fast,dPhiil_fast,-dH_Phiil,                # fast tendencies
                Fjk,dSik_slow,dujk_slow,dPhiil_slow,dWil_slow ) # slow tendencies

################## Fully equipped shallow-atmosphere metric  ##################

class Shallow(Shallow_hydro, Shallow_NH):
    def __init__(self, mesh, dx, g0):
        self.dx, self.g0  = dx, g0
        self.dx2, self.g2 = dx*dx, g0*g0
        self.dx_g0, self.g0_dx = dx/g0, g0/dx
        self.mesh, xmesh, zmesh = mesh, mesh.xmesh, mesh.zmesh
        self.xmesh, self.zmesh = xmesh, zmesh
        self.di, self.dj = xmesh.di, xmesh.dj
        self.mi, self.mj = xmesh.mi, xmesh.mj
        self.dk, self.dl = zmesh.dk, zmesh.dl
        self.mk_int, self.ml_int = zmesh.mk_int, zmesh.ml_int
        self.mk_ext, self.ml_ext = zmesh.mk_ext, zmesh.ml_ext
        self.xik = mesh.xik*dx
        self.xjk = mesh.xjk*dx
        self.xjl = mesh.xjl*dx
        self.xil = mesh.xil*dx
        self.xi  = xmesh.xi*dx
    def volume(self, phi):  # V(Phi), J=dV/dPhi
        return phi*self.dx_g0, self.dx_g0

######################## Lagrangian vertical coordinate #####################

class Coord:
    def __init__(self, dyn):
        self.dyn, self.metric = dyn, dyn.metric
        
class LagrangianHydro(Coord):
    def bwd_fast_slow(self, flow, tau):
        dyn=self.dyn
        mik, Sik, ujk, Phiil, Wil, Mjk, Mil =  flow # Phiil, Wil ignored
        ujk, dujk_fast, Fjk, dSik, dujk = dyn.bwd_fast_slow(mik, Sik, ujk, tau)
        flow = (mik, Sik, ujk, 0., 0., Mjk, Mil)
        fast = (0., 0., dujk, 0., 0., 0., 0.)
        dmik = -dyn.di(Fjk)
        slow = (dmik, dSik, dujk, 0., 0., Fjk, 0.)
        return flow, fast, slow

class LagrangianNH(Coord):
    def bwd_fast_slow(self, flow, tau):
        dyn=self.dyn
        mik, Sik, ujk, Phiil, Wil, Mjk, Mil =  flow
        ujk, Phiil, Wil, \
            dujk_fast, dPhiil_fast, dWil_fast, \
            Fjk, dSik, dujk, dPhiil, dWil = dyn.bwd_fast_slow(mik, Sik, ujk, Phiil, Wil, tau)
        flow = (mik, Sik, ujk, Phiil, Wil, Mjk, Mil)
        fast = (0., 0., dujk_fast, dPhiil_fast, dWil_fast, 0., 0.)
        dmik = -dyn.di(Fjk)
        slow = (dmik, dSik, dujk, dPhiil, dWil, Fjk, 0.)
        return flow, fast, slow

######################## Mass-based vertical coordinate #####################

class GeneralCoord(Coord):
    # this class computes the terms due to vertical transport (eta_dot)
    # given the vertical mass flux Fil
    def trend_vert_hydro(self, mik,Sik,ujk, Fil):
        dyn=self.dyn
        sik=Sik/mik
        sil=dyn.ml_int(sik) # centered
        dSik_dt = - dyn.dk(Fil*sil)
        dluj = dyn.dl(0.,ujk,0.)
        dujk_dt = - dyn.mk_ext(dluj*dyn.mj(Fil))/dyn.mj(mik)
        return dSik_dt, dujk_dt
    def trend_vert_NH(self, mik,Sik,ujk,Phi_il,Wil, Fil):
        dyn=self.dyn
        dSik, dujk = self.trend_vert_hydro(mik,Sik,ujk, Fil)
        Fik = dyn.mk_int(Fil)
        wik = dyn.mk_ext(Wil)/mik 
        fil = Fil/dyn.ml_ext(mik) # fil = eta_dot
        dujk = dujk - dyn.mj(wik*dyn.dk(Phi_il))*dyn.dj(Fik/mik)
        dWil = - dyn.dl(0.,Fik*wik,0.) # centered vertical flux of vertical momentum
        dPhiil = - fil*dyn.dl(0., dyn.mk_int(Phi_il), 0.)
        return dSik, dujk, dPhiil, dWil

class MassCoord(GeneralCoord):
    # computes the vertical mass flux for a mass-based coordinate
    def massflux(self,mik,Fjk):
        def sum(fik): return col_vec(fik.sum(1))*onesk
        mesh=self.metric.mesh
        onesk=mesh.zmesh.onesk
        # mik = Aik*Mi
        Mik=sum(mik)
        Aik = mik/Mik
        # dmik_mass = Aik*dMi = Aik*sumk(dmik_lag)
        dmik_lag = -self.dyn.di(Fjk)
        dMik = sum(dmik_lag)
        dmik_mass = Aik*dMik 
        #    dmik_lag  + di(Fjk)            = 0
        #    dmik_mass + di(Fjk) + dk(Fil)  = 0
        # => dmik_mass - dmik_lag + dk(Fil) = 0
        dkFil = dmik_lag - dmik_mass
        Fil = mesh.cumsum_il(mesh.xmesh.zeroi, dkFil)
        return Fil, dmik_mass

class MassBasedHydro(MassCoord):
    def bwd_fast_slow(self, flow, tau):
        mik, Sik, ujk, Phiil, Wil, Mjk, Mil =  flow # Phiil, Wil ignored
        ujk, dujk_fast, Fjk, dSik, dujk = self.dyn.bwd_fast_slow(mik, Sik, ujk, tau)
        flow = (mik, Sik, ujk, 0., 0., Mjk, Mil)
        fast = (0., 0., dujk_fast, 0., 0., 0., 0.)
        Fil, dmik = self.massflux(mik,Fjk)
        dSik_vert, dujk_vert = self.trend_vert_hydro(mik,Sik,ujk, Fil)
        slow = (dmik, dSik+dSik_vert, dujk+dujk_vert, 0., 0., Fjk, Fil)
        return flow, fast, slow

class MassBasedNH(MassCoord):
    def bwd_fast_slow(self, flow, tau):
        dyn=self.dyn
        mik, Sik, ujk, Phiil, Wil, Mjk, Mil =  flow
        ujk,Phiil,Wil, \
            dujk_fast,dPhiil_fast,dWil_fast, \
            Fjk, dSik, dujk, dPhiil, dWil = dyn.bwd_fast_slow(mik,Sik,ujk,Phiil,Wil, tau)
        flow = (mik, Sik, ujk, Phiil, Wil, Mjk, Mil)
        fast = (0.,0., dujk_fast,dPhiil_fast,dWil_fast, 0.,0.)
        Fil, dmik = self.massflux(mik,Fjk)
        dSik_vert, dujk_vert, dPhiil_vert, dWil_vert = self.trend_vert_NH(mik,Sik,ujk,Phiil,Wil,Fil)
        slow = (dmik, dSik+dSik_vert, dujk+dujk_vert, dPhiil+dPhiil_vert, dWil+dWil_vert, Fjk, Fil)
        return flow, fast, slow
