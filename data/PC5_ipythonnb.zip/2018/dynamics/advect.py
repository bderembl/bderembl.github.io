import numpy as np
from scipy import sparse as sparse

#-------------------------------- Strang-split advection --------------------------------

class SplitTransport:
    def __init__(self, metric, Horiz, Vert):
        # Horiz and Vert are classes for horizontal and vertical transport, respectively
        self.horiz = Horiz(metric)
        self.vert = Vert(metric)
        self.di, self.dk = metric.di, metric.dk
    def next(self, Fjk, Fil,  # time-integrated mass fluxes
             mik,             # mass field before advection
             scalars):        # tuple of 2D mass-weighted scalars to be advected
        scalars =  [Qik for Qik in self.vert.advect(.5*Fil,mik,scalars)]
        mik = mik - .5*self.dk(Fil)
        scalars =  [Qik for Qik in self.horiz.advect(Fjk,mik,scalars)]
        mik = mik - self.di(Fjk)
        scalars =  [Qik for Qik in self.vert.advect(.5*Fil,mik,scalars)]
        mik = mik - .5*self.dk(Fil)
        return mik, scalars
    
class HorizTransport:
    def __init__(self, metric, Horiz):
        self.horiz, self.di = Horiz(metric), metric.di
    def next(self, Fjk, Fil,  # time-integrated mass fluxes
             mik,             # mass field before advection
             scalars):        # tuple of 2D mass-weighted scalars to be advected
        scalars =  [Qik for Qik in self.horiz.advect(Fjk,mik,scalars)]
        mik = mik - self.di(Fjk)
        return mik, scalars
    
#---------------------------- Horizontal advection schemes ----------------------------

class HorizGodunov:
    def __init__(self,metric):
        self.di, self.dj = metric.di, metric.dj
        self.mi, self.mj = metric.mi, metric.mj
    # member function reconstruct() (to be overloaded by derived classes)
    # yields for each point j the mean and difference of right and left reconstructions 
    def reconstruct(self,Fjk,maik,scalars):
        for Qik in scalars:
            qik = Qik/maik
            yield Qik, self.mj(qik), self.dj(qik) # piecewise-constant reconstruction
    def advect(self,Fjk,maik,scalars):
        for Qik, mean_qr_ql, qr_minus_ql in self.reconstruct(Fjk,maik,scalars):
            qjk = mean_qr_ql - 0.5*np.sign(Fjk)*qr_minus_ql  # Upwind sub-grid reconstruction 
            yield Qik - self.di(qjk*Fjk)
            
class HorizVanLeer(HorizGodunov):
    def reconstruct(self,Fjk,mik,scalars):
        fjk = .5*Fjk/self.mj(mik) # displacement, same for all scalars
        for Qik in scalars:
            qik = Qik/mik
            delqik = self.di(self.mj(qik))
            mean_qr_ql =   self.mj(qik) - .25*self.dj(delqik) - fjk*self.mj(delqik)
            qr_minus_ql =  self.dj(qik) - self.mj(delqik)     - fjk*self.dj(delqik)
            yield Qik, mean_qr_ql, qr_minus_ql
            
#----------------------------- Vertical advection schemes ---------------------------------

class VertGodunov:
    def __init__(self,metric):
        self.dk, self.dl, self.ml = metric.dk, metric.dl, metric.ml_int
    # member function reconstruct() (to be overloaded by derived classes)
    # yields for each point j the mean and difference of right and left reconstructions 
    def advect(self,Fil,mik,scalars):
        for Qik, mean_qr_ql, qr_minus_ql in self.reconstruct(Fil,mik,scalars):
            qil = mean_qr_ql - 0.5*np.sign(Fil)*qr_minus_ql  # Upwind sub-grid reconstruction 
            yield Qik - self.dk(qil*Fil)
    def reconstruct(self,Fil,mik,scalars):
        for Qik in scalars:
            qik = Qik/mik
            yield Qik, self.ml(qik), self.dl(0.,qik,0.)

class VertVanLeer(VertGodunov):
    def reconstruct(self,Fil,mik,scalars):
        fil = .5*np.array(Fil/self.ml(mik)) # displacement, same for all scalars
        for Qik in scalars:
            qik = Qik/mik
            qil = self.ml(qik)
            delqik = self.dk(qil) # subgrid slope, FIXME at top and bottom
            mean_qr_ql  = self.ml(qik)     - .25*self.dl(0,delqik,0) - fil*self.ml(delqik)
            qr_minus_ql = self.dl(0,qik,0) - self.ml(delqik)         - fil*self.dl(0,delqik,0)
            yield Qik, mean_qr_ql, qr_minus_ql
    
#--------------------- Sarvesh original code -------------------------

class adv:
    def __init__(self,metric,maik,qik,Uajk,Fail):
        self.metric = metric
        self.maik=maik
        self.qik=qik 
        self.Uajk=Uajk
        self.Fail=Fail 
        self.di, self.dj = metric.di, metric.dj
        self.dk, self.dl = metric.dk, metric.dl
        self.mi, self.mj = metric.mi, metric.mj
        Nx, Ny = np.shape(maik)
        ones=np.ones(Nx);
        left = sparse.spdiags([ones],[-1],Nx,Nx, format='csr')
        left[0,-1]=1
        right = sparse.spdiags([ones],[1],Nx,Nx, format='csr')
        right[-1,0]=1
        self.left =lambda f:left.dot(f)
        self.right =lambda f:right.dot(f)
        self.mk_ext, self.ml_ext = metric.mk_ext, metric.ml_ext
        self.mk_int, self.ml_int = metric.mk_int, metric.ml_int

    def adv_horizon(self,maik,qik,Uajk):
        maik_old = maik  # Mass at the start of the advection (before N-adv dynamical steps)  
        qik_r = self.right(qik)
        maik_r = self.right(maik)
        qik_l = self.left(qik)
        delqik = 0.5*(qik_r-qik_l)
        qr = qik + 0.5*(1 - Uajk/maik)*delqik
        ql = qik_r - 0.5*(1 + Uajk/maik_r)*self.right(delqik)
        qUPjk= 0.5*((qr+ql) + np.sign(Uajk)*(qr-ql))  ##Upwind sub-grid reconstruction 
        qxflx = qUPjk*Uajk
        maik = maik - self.di(Uajk) ## Updated Mass 
        qik = (qik*maik_old - self.di(qxflx))/maik
        return maik,qik
    
    def adv_horizon1(self,maik,qik,Uajk):
        maik_old = maik  # Mass at the start of the advection (before N-adv dynamical steps)  
        qjk = self.mj(qik)
        delqik = self.di(qjk)
        qik_r = qik + 0.5*(1 - Uajk/maik)*delqik
        qik_l = np.zeros(np.shape(qik))
        qik_l[:-1,:] = qik[1:,:]-0.5*(1.0 - Uajk[:-1,:]/maik[1:,:])*delqik[1:,:]
        qik_l[-1,:] = qik[0,:] - 0.5*(1.0 - Uajk[-1,:]/maik[0,:])*delqik[0,:]
        qUPjk= 0.5*((qik_r+qik_l) + np.sign(Uajk[:,:])*(qik_r-qik_l))
        qxflx = qUPjk*Uajk
        maik = maik - self.di(Uajk) ## Updated Mass 
        qik = (qik*maik_old - self.di(qxflx))/maik
        return maik,qik
    
    def adv_godnov(self,maik,qik,Uajk):
        maik_old = maik  # Mass at the start of the advection (before N-adv dynamical steps)  
        qjk = self.mj(qik)
        qik_r = qik 
        qik_l = np.zeros(np.shape(qik))
        qik_l[:-1,:] = qik[1:,:]
        qik_l[-1,:] = qik[0,:] 
        qUPjk= 0.5*((qik_r+qik_l) + np.sign(Uajk[:,:])*(qik_r-qik_l))
        qxflx = qUPjk*Uajk
        maik = maik - self.di(Uajk) ## Updated Mass 
        qik = (qik*maik_old - self.di(qxflx))/maik
        return maik,qik
    
    def adv_vert(self,maik,qik,Fil):
        maik_old = maik
        qil = self.ml_int(qik)
        delqik = self.dk(qil) # subgrid slope 
        qrik = qik[:,:-1] + 0.5*(1 - Fil[:,1:-1]/maik[:,:-1])*delqik[:,:-1]
        qlik = qik[:,1:] - 0.5*(1 - Fil[:,1:-1]/maik[:,1:])*delqik[:,1:]
      
        qUPil = np.zeros(np.shape(Fil))
        qUPil[:,1:-1]= 0.5*((qrik+qlik) + np.sign(Fil[:,1:-1])*(qrik-qlik))
        qUPil[:,0]= 0.0 #qik[:,0] - 0.5*(1 - Fil[:,0]/maik[:,0])*delqik[:,0]
        qUPil[:,-1]= 0.0 #qik[:,-1] + 0.5*(1 - Fil[:,-1]/maik[:,-1])*delqik[:,-1]
        qzflx = qUPil*Fil
        maik = maik - self.dk(Fil)
        qik = (qik*maik_old - self.dk(qzflx))/maik
        return maik,qik
    
    def adv_vgod(self,maik,qik,Fil):
        maik_old = maik
        qrik = qik[:,:-1]
        qlik = qik[:,1:]       
        qUPil = np.zeros(np.shape(Fil))
        qUPil[:,1:-1]= 0.5*((qrik+qlik) + np.sign(Fil[:,1:-1])*(qrik-qlik))
        qUPil[:,0]= 0.0
        qUPil[:,-1]= 0.0
        qzflx = qUPil*Fil
        maik = maik - self.dk(Fil)
        qik = (qik - self.dk(qzflx)) #/maik
        return maik,qik