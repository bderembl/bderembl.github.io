import numpy as np
from scipy import sparse as sparse
import math as math

xrange = range # Python 3

class Struct: pass

def Linf(data):
    return abs(data).max()
def compare(msg, data1, data2):
    print (msg, Linf(data1-data2)/Linf(data1))    

############################# Tridiagonal solver #############################

class SymTriDiag:
    """ Solve -c(i-1)x(i-1) + b(i)x(i) - c(i)x(i+1) = d(i)
    Forward sweep :
    C(i) =        -c(i)       / (b(i)+c(i-1)C(i-1)), C(0)=0
    D(i) = (d(i)+c(i-1)D(i-1)) / (b(i)+c(i-1)C(i-1)), D(0)=0
    Back substituion :
    x(i) = D(i)-C(i)x(i+1), x(N+1)=0
    """
    def __init__(self, b,c):
        M, N = b.shape
        self.M, self.N, self.b, self.c = M,N,b,c
        B,C = np.zeros((M,N)), np.zeros((M,N-1))
        Bi = b[:,0]
        B[:,0]=Bi
        for i in xrange(1,N):
            Ci = -c[:,i-1]/Bi
            C[:,i-1]=Ci
            Bi = b[:,i]+c[:,i-1]*Ci
            B[:,i]=Bi
        self.B, self.C = B,C
    def dot(self,x):
        M,N,b,c = self.M, self.N, self.b, self.c
        y = np.zeros((M,N))
        y[:,0] = b[:,0]*x[:,0] - c[:,0]*x[:,1]
        for i in xrange(1,N-1):
            y[:,i] = -c[:,i-1]*x[:,i-1] + b[:,i]*x[:,i] - c[:,i]*x[:,i+1]
        y[:,N-1] = -c[:,N-2]*x[:,N-2] + b[:,N-1]*x[:,N-1]
        return y
    def solve(self,d):
        M,N,c,B,C = self.M, self.N, self.c, self.B, self.C
        D,x = np.zeros((M,N)), np.zeros((M,N))
        Di = d[:,0]/B[:,0]
        D[:,0]=Di
        for i in xrange(1,N):
            Di = (d[:,i]+c[:,i-1]*Di)/B[:,i]
            D[:,i]=Di
        xi=D[:,N-1]
        x[:,N-1]=xi
        for i in xrange(N-2,-1,-1):
            xi = D[:,i]-C[:,i]*xi
            x[:,i]=xi
        return x

########################### ARK time schemes ##########################

class SIRK:
    """ 
    Generic SIRK scheme with fast/slow Butcher tableaux (af,wf), (as,ws)
    Following Weller et al. (2013)
    sj=slow(yj), fj=fast(yj)
    zj = y(n) + dt*( sum(l<j)asjl*sl + sum(l<j)afjl*fl )
    yj = zj + dt*afjj*fast(yj)
    y(n+1) = y(n)+dt*sum(wsj*sj+wsf*fj)
    self.fast solves y = z + tau*fast(y) for y, returns y and fast(y)
    """
    def advance(self, flow, N):
        for k in range(N):
            flow=self.next(flow)
        return flow
    def next_old(self, yn):
        dt = self.dt
        asjl, afjl = dt*self.asjl, dt*self.afjl
        fastj, slowj = [], []
        for j in range(self.nstage):
            zj = yn
            for l in range(0,j):
                zj = [z + asjl[j,l]*s + afjl[j,l]*f for z,s,f in zip(zj, slowj[l], fastj[l]) ]
            yj, fj = self.fast(zj, afjl[j,j])
            fastj.append(fj)
            slowj.append(self.slow(*yj))
        for j in range(0,self.nstage):
            yn = [y + (dt*self.wsj[j])*s + (dt*self.wfj[j])*f for y,s,f in zip(yn, slowj[j], fastj[j]) ]
        return yn
    """
    Reformulation : remarking that 
    y(j)   = y(n) + dt*sum_(l<=j)[as(j,l)*s(l)   + af(j,l)*f(l) ]
    z(j+1) = y(n) + dt*sum_(l<=j)[as(j+1,l)*s(l) + af(j+1,l)*f(l) ]
           = y(j) + dt*sum_(l<=j)[cs(j,l)*s(l)   + cf(j,l)*f(l) ]
    where b(j,l)=a(j,l) ; b(nstage,l)=w(l) ; c(j) = b(j+1)-b(j) => c0=b1
    => new implementation
    z(0) = y(n)
    DO j=0, nstage-1
        [y(j), fj, sj] = bwd_fast_slow(z(j),0.)
        z(j+1) = y(j) + dt*sum_(l<=j)[cs(j,l)*s(l) + cf(j,l)*f(l) ]
    END DO
    y(n+1) = z(nstage)

    where z(j) and y(j) are actually stored in a single variable zj
    and [y,f,s] = bwd_fast_slow(z,tau) 
        * solves y - tau*fast(y) = z
        * computes f=fast(y) and s=slow(y)
    """
    def cjl(self,a,w):
        nstage=self.nstage
        c=np.zeros((nstage,nstage))
        for j in range(nstage-1):
            for l in range(nstage):
                c[j,l]=a[j+1,l]-a[j,l]
        for l in range(nstage):
            c[-1,l]=w[l]-a[-1,l]
        return c
    def finalize_init(self,bwd_fast_slow, dt,nstage, asjl,wsj,afjl,wfj): # must be called for next() to work
        self.bwd_fast_slow = bwd_fast_slow
        self.dt, self.nstage = dt, nstage
        self.csjl = dt*self.cjl(asjl, wsj)
        self.cfjl = dt*self.cjl(afjl, wfj)
        self.afjl = dt*afjl
    def next(self,yn):
        csjl, cfjl, afjl = self.csjl, self.cfjl, self.afjl
        fastj, slowj = [], []
        zj = yn
        for j in range(self.nstage): # here zj is z(j)
            zj, fj, sj = self.bwd_fast_slow(zj, afjl[j,j])
            fastj.append(fj)
            slowj.append(sj)
            for l in range(0,j+1): # here zj is initially y(j) and finally z(j+1)
                zj = [z + csjl[j,l]*s + cfjl[j,l]*f for z,s,f in zip(zj, slowj[l], fastj[l]) ]
        return zj        
    
class SIRK1(SIRK):
    """ Forward-Backward""" 
    def __init__(self, slow,fast,solver,dt):
        self.asjl = np.array([[0]])
        self.afjl = np.array([[1]])
        self.wsj  = np.array([1])
        self.nstage, self.dt, self.wfj = 1,dt,self.wsj
        self.slow, self.fast, self.solver = slow, fast, solver

class ARK2(SIRK):
    """ ARK2 scheme by Giraldo et al. (2013), noted ARK2(2,3,2) in Weller et al. (2013) """ 
    def __init__(self, bwd_fast_slow, dt, a32 = (3.+2.*np.sqrt(2.))/6.):
        gamma = 1.-1./np.sqrt(2.)
        delta = 1./(2.*np.sqrt(2.))
        asjl = np.array([[0,0,0],[2.*gamma,0,0],[1.-a32,a32,0]])
        afjl = np.array([[0,0,0],[gamma,gamma,0],[delta,delta,gamma]])
        wj  = np.array([delta,delta,gamma])
        self.finalize_init(bwd_fast_slow,dt,3,asjl,wj,afjl,wj)
        
class UJ3(SIRK):
    """ Strang-carryover scheme by Ullrich et al. (2013), noted UJ3(1,3,2) in Weller et al. (2013) """
    def __init__(self, bwd_fast_slow, dt):
        zz  = [0,0,0,0,0,0]
        wsj = [0,1/6.,1/6.,2/3.,0,0]
        h  = [.5,0,0,0,0,0]
        wfj = [.5,0,0,0,0,.5]
        self.asjl = np.array([zz,zz,[0,1,0,0,0,0],
                              [0,.25,.25,0,0,0],wsj,wsj])
        self.afjl = np.array([zz,h,h,h,h,wfj])
        self.wsj  = np.array(wsj)
        self.wfj  = np.array(wfj)
        self.nstage, self.dt = 6,dt
        self.finalize_init(bwd_fast_slow)

######### Explicit RK schemes written as ARK with two identical Butcher tableaus ########

class RK_simple(SIRK):
    def next_old(self, flow0):
        flow1=flow0
        for tau in self.tau:
            trend=self.trend(*flow1) # split tuple flow1 into arguments for trend
            flow1 = [x+tau*y for x,y in zip(flow0,trend)]
        return flow1

class RK_Kinnmark(RK_simple):
    """ RK schemes with max stability along imaginary axis
        Kinnmark & Gray, 1984 """
    def __init__(self, K, trend, dt):
        self.trend, self.dt = trend, dt
        ee=np.zeros((K+1,K+1))
        ee[2,0], ee[2,1], ee[2,2] = 1,1,1
        ee[3,0], ee[3,1], ee[3,2], ee[3,3] = 1,2,2,2
        for k in range(4,K+1):
            ee[k,0]=1
            for n in range(1,k+1):
                ee[k,n]=ee[k-2,n]+2*ee[k-1,n-1]
        self.tau = [dt*ee[K,K-n]/ee[K,K-n-1]/(K-1) for n in range(K)]
    
class RK4_simple(RK_simple):
    def __init__(self, trend, dt):
        self.trend, self.dt = trend, dt
        self.tau = (dt/4., dt/3., dt/2., dt)

class RK3_simple(RK_simple):
    def __init__(self, trend, dt):
        self.trend, self.dt = trend, dt
        self.tau = (dt/3., dt/2., dt)
